﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Animal animal = new Animal();
            Animal fish = new fish();
            Animal bird = new bird();
            Eagle eagle = new Eagle();
            Pegion pegion = new Pegion();
            animal.Move();
            fish.Move();
            bird.Move();
            eagle.Move();
            pegion.Move();
        }
    }

    class Animal
    {
        public virtual string Name => "动物";
        public virtual void Move()
        {
            Console.WriteLine(Name+"开始运动");
        }
    }

    class fish:Animal
    {
        public override void Move()
        {
            Console.WriteLine(Name + "开始运动");
            Swim();
        }
        private void Swim()
        {
            Console.WriteLine(Name+"在水中游") ;
        }
        public override string Name => "鱼";
    }

    class bird : Animal
    {
        public override void Move()
        {
            Console.WriteLine(Name + "开始运动");
            fly();
        }
        private void fly()
        {
            Console.WriteLine(Name + "在天上飞");
        }
        public override string Name => "鸟";
    }

    class Eagle:bird
    {
        public override string Name => "Eagle";
    }
    class Pegion : bird
    {
        public override string Name => "Pegion";
    }
}
