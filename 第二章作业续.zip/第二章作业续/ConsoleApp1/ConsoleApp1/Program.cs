﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Person p = new Father();
            p.Name = "Obama";
            p.Task();

            Father q = new Son();
            q.Name = p.Name;
            q.Son_Name = "Oguanhai";
            q.Task();
            Father s = new GrandSon();
            s.GrandSon_Name = "Oleo";
            s.Son_Name = "Oguanhai";
            s.Name = "Obama";
            
            s.Task();
            Console.ReadKey();

        }
    }

    abstract class Person
    {
        public virtual string Name { set; get; }
        public virtual void Task()
        {
            Console.WriteLine("One of the tasks of man is to reproduce ");
        }
        public Person() {; }
        public Person(string n)
        {
            Name = n;
        }
    }

    class Father : Person
    {

        public override string Name { get; set; }
        public string Son_Name { set; get; }
        public string GrandSon_Name { set; get; }
        public override void Task()
        {
            base.Task();
            Console.WriteLine("Father {0}'s task is have a baby and give he(she) a Name",Name);
        }
    }

    class Son : Father
    {
        public override string Name { get => Son_Name;  }

        public override void Task()
        {
            Console.WriteLine("Son {0}'s task is make his father {1} have a grandson or granddauther and give his baby a Name", Name, base.Name);
        }
    }

    class GrandSon:Son
    {
        public override string Name { get => GrandSon_Name; }
        public override void Task()
        {
            Console.WriteLine("GrandSon {0}'s task is study hard and help his fataer {1}", Name, base.Name);
        }
    }
}
