﻿using System;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            Ellipse ellipse = new Ellipse();
            Circle circle = new Circle();
            ellipse.A = 3;
            ellipse.B = 4;
            circle.A = 3;
            Console.WriteLine(ellipse.GetC());
            Console.WriteLine(ellipse.GetS());
            Console.WriteLine(circle.GetC());
            Console.WriteLine(circle.GetS());
        } 
    }

    interface IShape
    {
        double A { get; set; }
        double B { get;  }
        double GetC();
        double GetS();
    }

    class Ellipse : IShape
    {
        public double A { get; set ; }
        public double B { get; set ; }

        public double GetC()
        {
            return 2 * Math.PI * B + 4 * (A - B);
        }
        public double GetS()
        {
            return A * B * Math.PI;
        }
    }

    class Circle : IShape
    {
        public double A { get; set; }
        public double B => A;

        public double GetC()
        {
            return 2 * Math.PI * B + 4 * (A - B);
        }
        public double GetS()
        {
            return A * B * Math.PI;
        }
    }
}
