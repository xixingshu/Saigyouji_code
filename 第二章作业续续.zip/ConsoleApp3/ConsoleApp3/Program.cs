﻿using System;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            Shape ellipse = new Ellipse();
            Shape circle = new Circle();
            ellipse.A = 3;
            ellipse.B = 4;
            circle.A = 3;
            Console.WriteLine(ellipse.GetS());
            Console.WriteLine(ellipse.GetC());
            Console.WriteLine(circle.GetS());
            Console.WriteLine(circle.GetC());
        }
    }

    abstract class Shape
    {
        public double A { get; set; }
        public double B { get; set; }
        public abstract double GetS();
        public abstract double GetC();
    }

    class Ellipse : Shape
    {

        public override double GetS()
        {
            return A * B * Math.PI;
        }

        public override double GetC()
        {
            return 2 * Math.PI * B + 4 * (A - B);
        }

    }

    class Circle : Shape
    {

        public override double GetS()
        {
            return A * A * Math.PI;
        }

        public override double GetC()
        {
            return 2 * Math.PI * A;
        }

    }
}
